var Game = require("./game");

var game = new Game();
game.start();
